package pageObjects;



import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import testbase.TestBase;

public class Hiver_service extends TestBase{



	@FindBy(how=How.XPATH, using ="//span[@class='navigation__link ga_send']")
	public WebElement Getfreetrial;


	@FindBy(how=How.NAME, using= "full_name")
	public WebElement Fullnametextbox;

	@FindBy(how=How.XPATH, using= "//input[@type='tel']")
	public WebElement telephonetextbox;

	@FindBy(how=How.NAME, using= "email")
	public WebElement emailtextbox;

	@FindBy(how=How.XPATH, using= "//input[@value='Get Started']")
	public WebElement submitbutton;

	// Google Sign In

	@FindBy(how=How.XPATH, using= "//input[@type='email']")
	public WebElement googlemailtextbox;

	@FindBy(how=How.XPATH, using= "(//div[@class='VfPpkd-RLmnJb'])[1]")
	public WebElement Nextbutton;

	@FindBy(how=How.XPATH, using= "//input[@type='password']")
	public WebElement googlpasswordtextbox;

	@FindBy(how=How.XPATH, using= "//button[contains(text(),'Next')]")
	public WebElement hivernextbutton;

	@FindBy(how=How.XPATH, using= "//input[@placeholder='support@company.com']")
	public WebElement hiversupportmail;

	@FindBy(how=How.XPATH, using= "//input[@placeholder='Eg : Support']")
	public WebElement sharemailboxname;

	@FindBy(how=How.XPATH, using= "(//span[@class='sc-jhAzac jJvxcV'])[1]")
	public WebElement connectgoogle;

	@FindBy(how=How.XPATH, using= "//a[@class='sc-gipzik cpUhVn']")
	public WebElement illdothislater;

	@FindBy(how=How.XPATH, using= "//span[@class='SVGInline flaunt-download']")
	public WebElement downloadextension;

	@FindBy(how=How.XPATH, using= "(//div[contains(text(),'Add to Chrome')])[1]")
	public WebElement AddtoChrome;

	public Hiver_service(){
		PageFactory.initElements(driver, this);
	}
	public void clicknew()
	{
		Getfreetrial.click();

	}

	public void login(String name, String tel, String email) throws InterruptedException {
		Fullnametextbox.sendKeys(name);
		telephonetextbox.sendKeys(tel);
		emailtextbox.click();
		Thread.sleep(2000);
		emailtextbox.clear();
		emailtextbox.sendKeys(email);
		emailtextbox.sendKeys(Keys.TAB);
		Thread.sleep(2000);
		submitbutton.click();
		Thread.sleep(9000);

	}
	public void clicksubmit() throws InterruptedException {
		submitbutton.click();
	}


	public void googlesignin(String email,String pass) throws InterruptedException {
		googlemailtextbox.clear();
		googlemailtextbox.sendKeys(email);
		Thread.sleep(5000);
		Nextbutton.click();
		Thread.sleep(5000);
		googlpasswordtextbox.sendKeys(pass);
		Thread.sleep(5000);
		Nextbutton.click();
		Thread.sleep(5000);


	}

	public void clickhivernext(String supmail,String mailboxname,boolean now) throws InterruptedException, AWTException
	{
		Thread.sleep(9000);
		hivernextbutton.click();
		Thread.sleep(9000);
		if(now)
		{
			hiversupportmail.sendKeys(supmail);
			Thread.sleep(9000);
			sharemailboxname.sendKeys(mailboxname);
			Thread.sleep(9000);

			driver.findElement(By.xpath("//div[@class='Select-control']")).sendKeys("studycbit@gmail.com");
			driver.findElement(By.xpath("//div[@class='Select-control']")).sendKeys(Keys.TAB);
			hivernextbutton.click();
			String winHandleBefore = driver.getWindowHandle();

			Thread.sleep(9000);                                                                                                    
			connectgoogle.click();

			//New Window
			for(String winHandle:driver.getWindowHandles())
			{
				driver.switchTo().window(winHandle);
			}

			googlesignin("geethanjali2300@gmail.com","******");
			Thread.sleep(9000);
			driver.findElement(By.xpath("(//div[@class='VfPpkd-RLmnJb'])[1]")).click();

			//			driver.close();

			driver.switchTo().window(winHandleBefore);

		}
		else
		{
			illdothislater.click();
		}
		Thread.sleep(9000);
		downloadextension.click();
		Thread.sleep(9000);
		AddtoChrome.click();
		Thread.sleep(9000);
		Robot rb=new Robot();
		rb.keyPress(KeyEvent.VK_TAB);
		Thread.sleep(8000);
		rb.keyPress(KeyEvent.VK_ENTER);


	}
	public void switchtogmail() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver,60);
		String newtab=driver.getWindowHandle();
		Thread.sleep(8000);
		driver.switchTo().window(newtab);
		//		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@target='h-support-mailbox-1']")));
		//		driver.findElement(By.xpath("//div[contains(text(),'Continue')]")).click();


	}

	public void signoutfromallgmail() throws InterruptedException {
		String newtab=driver.getWindowHandle();
		driver.switchTo().window(newtab);
		driver.findElement(By.xpath("//img[@class='gb_Ha gbii']")).click();

		Thread.sleep(5000);

		driver.findElement(By.xpath("//a[contains(text(),'Sign out')]]")).click();

		Thread.sleep(5000);

		driver.findElement(By.xpath("//div[contains(text(),'Use')]")).click();

		driver.manage().deleteAllCookies();
		googlesignin("paul.gitanjali2308@gmail.com","******");




	}

}




