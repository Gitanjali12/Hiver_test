package utilities;


	
	
	import java.util.function.Function;

	import org.openqa.selenium.JavascriptExecutor;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.support.ui.Wait;
	import org.openqa.selenium.support.ui.WebDriverWait;

	import testbase.TestBase;


public class TestUtilities {
		
		private static final WebDriver driver = null;
		public static int PAGE_LOAD_TIMEOUT = 60;
		public static int IMPLICIT_WAIT = 30;
		
		public static void waitForPageLoad() {

		    Wait<WebDriver> wait = new WebDriverWait(driver, 30);
		    wait.until(new Function<WebDriver, Boolean>() {
		        public Boolean apply(WebDriver driver) {
		            System.out.println("Current Window State       : "
		                + String.valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState")));
		            return String
		                .valueOf(((JavascriptExecutor) driver).executeScript("return document.readyState"))
		                .equals("complete");
		        }
		    });
		}
	}

	
