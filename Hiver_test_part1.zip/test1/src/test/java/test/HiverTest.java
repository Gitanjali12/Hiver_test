package test;


import java.awt.AWTException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import pageObjects.Hiver_service;
import testbase.TestBase;


public class HiverTest extends TestBase{

	
	Hiver_service homePageObj;
	public HiverTest() {
		super();
		//initialization();
	}
	
	@Test(priority =1)
	public void verifyHomePageTitle() throws InterruptedException, AWTException
	{ 
		test = report.startTest("Hiver Report");
		homePageObj= new Hiver_service();
		
		// Click Get Hiver Free
		homePageObj.clicknew();
		driver.manage().deleteAllCookies();
		test.log(LogStatus.PASS, "Clicked on Get Hiver Free");
		Thread.sleep(5000);
		homePageObj.login("Geet", "7439679533", "paul.geetanjali2311@gmail.com");
		
		String ActualTitle = driver.getTitle();
		System.out.println(ActualTitle);
		Assert.assertTrue("Sign in � Google accounts".equals(ActualTitle));
		
		test.log(LogStatus.PASS, "Signup Succesful");
		
		homePageObj.googlesignin("paul.geetanjali2311@gmail.com","******");
		
		test.log(LogStatus.PASS, "Google Sign in Successful");
		Thread.sleep(5000);
		String hiverActualTitle = driver.getTitle();
		System.out.println(hiverActualTitle);
		Assert.assertTrue("Hiver� | Shared Inbox Collaboration | Team Email Management".equals(hiverActualTitle));
		test.log(LogStatus.PASS, "Hiver Title Validation successful");
		
		
		homePageObj.clickhivernext("geethanjali2300@gmail.com", "Newmailbox",true);
		
		test.log(LogStatus.PASS, "Shared Mailbox is set successfully");
		test.log(LogStatus.PASS, "Hiver Extension is added successfully");
		
		//Switch to gmail and check the created mailbox in left side pane
		homePageObj.switchtogmail();
		
		test.log(LogStatus.PASS, "Shared mailbox is displayed in left side panel in USER A");
		
		// signout from all gmail accounts and sign in with new gmail account as USER X
		homePageObj.signoutfromallgmail();
		
		//Send an email to shared mail id
		
		//sign to User A and check mail appearing in the unassigned section on left side pane under shared mailbox
		
		//sign to User B and check mail appearing in the unassigned section on left side pane under shared mailbox
		
	}	
	
}
